module Main (main) where

import AppMain(appMain) 

main :: IO ()
main = appMain 
